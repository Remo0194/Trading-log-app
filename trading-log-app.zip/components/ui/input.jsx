export function Input(props) {
  return (
    <input
      {...props}
      className="border border-gray-300 rounded-2xl px-2 py-1 text-sm"
    />
  );
}
