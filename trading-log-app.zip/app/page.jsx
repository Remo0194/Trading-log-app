import TradeLogger from "../components/TradeLogger";
export default function Home() {
  return <TradeLogger />;
}
