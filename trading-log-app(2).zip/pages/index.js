import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/lib/supabaseClient";

export default function TradeLogger() {
  const [trades, setTrades] = useState([]);
  const [form, setForm] = useState({
    date: "",
    type: "",
    structure: "",
    entry: "",
    sl: "",
    tp: "",
    result: "",
    notes: "",
  });

  useEffect(() => {
    fetchTrades();
  }, []);

  const fetchTrades = async () => {
    const { data, error } = await supabase.from("trades").select("*").order("date", { ascending: false });
    if (!error) setTrades(data);
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    const { error } = await supabase.from("trades").insert([form]);
    if (!error) {
      setForm({ date: "", type: "", structure: "", entry: "", sl: "", tp: "", result: "", notes: "" });
      fetchTrades();
    }
  };

  return (
    <div className="p-4 space-y-4">
      <Card>
        <CardContent className="grid grid-cols-2 gap-4 p-4">
          <Input name="date" placeholder="Fecha" value={form.date} onChange={handleChange} />
          <Input name="type" placeholder="Tipo (Compra/Venta)" value={form.type} onChange={handleChange} />
          <Input name="structure" placeholder="Estructura" value={form.structure} onChange={handleChange} />
          <Input name="entry" placeholder="Entrada" value={form.entry} onChange={handleChange} />
          <Input name="sl" placeholder="Stop Loss" value={form.sl} onChange={handleChange} />
          <Input name="tp" placeholder="Take Profit" value={form.tp} onChange={handleChange} />
          <Input name="result" placeholder="Resultado (R)" value={form.result} onChange={handleChange} />
          <Input name="notes" placeholder="Notas" value={form.notes} onChange={handleChange} />
          <Button onClick={handleSubmit}>Registrar operación</Button>
        </CardContent>
      </Card>
      <div className="space-y-2">
        {trades.map((trade, index) => (
          <Card key={index} className="p-2">
            <CardContent>
              <div className="text-sm">📅 {trade.date} | 📈 {trade.type} | 🔁 {trade.structure}</div>
              <div className="text-xs">🎯 Entrada: {trade.entry} | 🛑 SL: {trade.sl} | 🎯 TP: {trade.tp} | 📊 R: {trade.result}</div>
              <div className="text-xs text-gray-500">📝 {trade.notes}</div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}